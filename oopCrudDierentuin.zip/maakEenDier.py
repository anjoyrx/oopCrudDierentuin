# maakEenDier.py
# Anjo Eijeriks
#2023/03/04
 
from Dier import Dier			# omdat we oop doen
nieuw_dier = Dier(1, "aap", "Charlie");
print(nieuw_dier.dierid);
print(nieuw_dier.naam);
print(nieuw_dier.soort);